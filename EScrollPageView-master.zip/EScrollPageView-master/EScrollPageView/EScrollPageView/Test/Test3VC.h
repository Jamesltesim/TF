//
//  Test3VC.h
//  EScrollPageView
//
//  Created by Easy on 2018/6/7.
//  Copyright © 2018年 Easy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "ENestScrollPageView.h"
#import "EWaterFallView.h"
@interface Test3VC : UIViewController

@end





/***************************************/

@interface Test3HeadView : UIView

@property(nonatomic,retain)UIImageView *bgImageView;        //背景图

@end










