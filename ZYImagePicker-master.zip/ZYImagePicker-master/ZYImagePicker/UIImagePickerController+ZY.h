//
//  UIImagePickerController+ZY.h
//  JadeSource
//
//  Created by Daniel on 16/12/12.
//  Copyright © 2016年 Daniel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImagePickerController (ZY)

@end
