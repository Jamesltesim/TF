//
//  AppDelegate.h
//  BeaconBroadCasting
//
//  Created by James on 2018/6/25.
//  Copyright © 2018年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

