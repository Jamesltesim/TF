//
//  AppDelegate.h
//  CompressedPictureDemo
//
//  Created by 毛织网 on 2018/6/25.
//  Copyright © 2018年 CDY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

