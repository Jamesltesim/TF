//
//  ResetSizeImage.h
//  Image
//
//  Created by goldeneye on 2017/4/24.
//  Copyright © 2017年 goldeneye by smart-small. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ResetSizeImage : NSObject


//- (NSData *)resetSizeOfImageData:(UIImage *)source_image maxSize:(int)maxSize;


- (NSData *)resetSizeOfImageDataMethodTwo:(UIImage *)source_image maxSize:(int)maxSize;


@end
