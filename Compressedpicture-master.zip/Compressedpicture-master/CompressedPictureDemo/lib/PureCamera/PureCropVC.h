//
//  PureCropVC.h
//  PureCamerademo
//
//  Created by 五月 on 2018/4/4.
//  Copyright © 2018年 五月. All rights reserved.
//

#import "TOCropViewController.h"

@interface PureCropVC : TOCropViewController
//@property(nonatomic,assign) TOCropViewControllerAspectRatio  AspectRatio;

@end
